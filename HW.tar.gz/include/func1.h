extern foo1();
