extern foo2();
