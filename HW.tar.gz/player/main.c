int main()
{
	foo1();
	foo2();
}
