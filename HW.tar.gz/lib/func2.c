#include <stdio.h>

void foo2()
{
	printf("TWO!\n");
}
