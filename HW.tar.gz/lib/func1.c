#include <stdio.h>

void foo1()
{
	printf("ONE!!!\n");
}
